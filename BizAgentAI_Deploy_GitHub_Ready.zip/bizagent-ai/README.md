# 📦 BizAgent.AI

BizAgent.AI là nền tảng SaaS ứng dụng AI giúp SME tự động hóa marketing và CSKH.